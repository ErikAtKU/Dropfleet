Thank you for downloading the "Phantasy Star Online" Font Pack! 


There are a total of four fonts in this set:

pso_font.ttf
psoFOnewearl.ttf
psoHUmar.ttf
psoRAcast.ttf


Installation:

Unzip the downloaded files into a folder of your choosing.
Under Control Panel > Fonts, select 'Install New Font' from the File menu. 
Select the files that you unzipped from the download.

The fonts consist only of alphanumeric characters (capital and lowercase).

 
This font data is restricted to personal use, and for usage in PSO-related creations, activities, and website content. This includes any personal and public web pages that display PSO-related images and artwork, but may not be used for any profit. 

 

^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^


PSO BB Community Site: http://www.psobb.com


